/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancs;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author poo
 */
public class CompteCreditTest {
    
    public CompteCreditTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testCrearCompteCreditSenseSaldo() {
        CompteCredit cc = new CompteCredit("12345678", 600.0D);
        assertEquals(610.0D, cc.getFondosDisponibles(), 0.001);
    }

    @Test
    public void testCrearCompteCreditAmbSaldoCorrecte() throws Exception {
        CompteCredit cc = new CompteCredit("12345678", 500.0D, 600.0D);
        assertEquals(1100.0D, cc.getFondosDisponibles(), 0.001);
    }
    
    @Test(expected = Exception.class)
    public void testCrearCompteCreditAmbSaldoIncorrecte() throws Exception {
        CompteCredit cc = new CompteCredit("12345678", 9.0D, 600.0D);        
    }
    
    @Test
    public void testFondosDisponibles() throws Exception {
        CompteCredit cc = new CompteCredit("12345678", 500.0D, 600.0D);
        cc.reintegre(501.0D);
        assertEquals(599.0D, cc.getFondosDisponibles(), 0.001);
    }
}
