/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancs;

/**
 *
 * @author poo
 */
public class CompteCredit extends CompteCorrent{

    private double credit;

    public double getCredit() {
        return credit;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }
    
    public CompteCredit(String nom, double credit) {
        super(nom);
        setCredit (credit);
    }

    public CompteCredit(String nom, double saldo, double credit) throws Exception {
        super(nom, saldo);
        setCredit (credit);
    }
    
    @Override
    public double getFondosDisponibles (){       
        return getSaldo()+ credit;        
    }
}
