/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancs;

/**
 *
 * @author poo
 */
public class CompteRentable extends CompteEstalvis implements Rentable {

    public CompteRentable(String nom, double saldo) throws Exception {
        super(nom, saldo);
    }

    @Override
    public void capitalitzaInteres(){        
        setSaldo(getSaldo() + calculaInteres() + bonus());        
    }
    
    @Override
    public double bonus() {
        double bonus = 0D;

        if (getSaldo() >= MAX_LIMIT) {
            bonus = calculaInteres() * 0.30;
        } else if (getSaldo() >= MID_LIMIT) {
            bonus = calculaInteres() * 0.20;
        } else if (getSaldo() >= MIN_LIMIT) {
            bonus = calculaInteres() * 0.10;            
        }
        return bonus;
    }
}