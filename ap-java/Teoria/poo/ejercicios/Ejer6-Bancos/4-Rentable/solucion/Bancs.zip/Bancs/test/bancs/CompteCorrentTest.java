/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancs;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author poo
 */
public class CompteCorrentTest {
    
    public CompteCorrentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of setXecsMessos method, of class CompteCorrent.
     */
    @Test
    public void testCrearCompteCorrentSenseSaldo() {

        CompteCorrent cc = new CompteCorrent("12345678");
        
        assertEquals(10d, cc.getSaldo(), 0.001d);
        
    }
    
    @Test(expected = Exception.class)
    public void testCrearCompteCorrentSaldoInferiorMinim() throws Exception{
        
        CompteCorrent cc = new CompteCorrent("12345678", 5);
        
    }
    
    @Test
    public void testCrearCompteCorrentSaldoSuperiorMinim() throws Exception{
        
        CompteCorrent cc = new CompteCorrent("12345678", 50d);
        
        assertEquals(50d, cc.getSaldo(), 0.001d);
        
    }

    @Test
    public void testImposicion() throws Exception {        
        CompteCorrent cc = new CompteCorrent("12345678", 50d);
        cc.imposicio(50);
        assertEquals(100d, cc.getSaldo(), 0.001d);        
    }
    
    @Test(expected = Exception.class)
    public void testReintegroExcesivo() throws Exception{        
        CompteCorrent cc = new CompteCorrent("12345678", 50d);
        cc.reintegre(51);        
    }
}
