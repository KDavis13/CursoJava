/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancs;

/**
 *
 * @author poo
 */
public class CompteEstalvis extends CompteBancari{
    
    private static double tipusInteres=2.0d;
    
    public CompteEstalvis(String nom){
        
        super(nom);
        
    }
    
    public CompteEstalvis(String nom, double saldo) throws Exception{
        
        super(nom, saldo);
        
    }
    final public double calculaInteres(){
        
        return getSaldo() * (tipusInteres / 100);
        
    }
    
    public void capitalitzaInteres(){
        
        setSaldo(getSaldo() + calculaInteres());
        
    }
    
}
