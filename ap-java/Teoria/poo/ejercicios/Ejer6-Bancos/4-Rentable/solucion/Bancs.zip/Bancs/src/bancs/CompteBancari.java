/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancs;

//import java.util.logging.Level;
//import java.util.logging.Logger;

/**
 *
 * @author poo
 */
public abstract class CompteBancari {

    /**
     * @param args the command line arguments
     */
    private String numCompte;
    private double saldo;
    private static double qttInicial = 10.0d;

    @Override
    public String toString() {
        return  this.getClass().getSimpleName() + "{" + "numCompte=" + numCompte + ", saldo=" + saldo + '}';
    }

    //Mètodes
    public void imposicio(double quantitat){
        setSaldo(saldo+quantitat);
    }
    
    public void reintegre(double quantitat) throws Exception{
        if(quantitat <= getFondosDisponibles())
            setSaldo(getSaldo()-quantitat);            
        else
            throw new Exception("La cantidad del reintegro debe ser inferior al saldo");
        
    }
    
    //Métode fondos
    public double getFondosDisponibles (){
        return getSaldo();
    }
    
    //Constructors
    public CompteBancari(String numCompte, double saldo) throws Exception {
        this.numCompte = numCompte;
        if (saldo > qttInicial){
            this.saldo = saldo;
        }else{
            throw new Exception("La cantidad no puede ser inferior a 10€");
        }
    }

    public CompteBancari(String numCompte) {
        this.numCompte = numCompte;
        this.saldo = qttInicial;
    }
    
    //Setters & Getters
    public String getNumCompte() {
        return numCompte;
    }

    public void setNumCompte(String numCompte) {
        this.numCompte = numCompte;
    }

    public double getSaldo() {
        return saldo;
    }

    protected void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    private double getQttInicial() {
        return qttInicial;
    }

    private void setQttInicial(double qttInicial) {
        this.qttInicial = qttInicial;
    }
    
    /*public static void main(String[] args) {
        try {
            CompteBancari compte1 = new CompteBancari("AB00001", 500);
            compte1.reintegre(500);
            compte1.imposicio(400);
            System.out.println(compte1);
        } catch (Exception ex) {
            Logger.getLogger(
                CompteBancari.class.getName())
                    .log(Level.SEVERE, null, ex);
        }        
    }*/

}
