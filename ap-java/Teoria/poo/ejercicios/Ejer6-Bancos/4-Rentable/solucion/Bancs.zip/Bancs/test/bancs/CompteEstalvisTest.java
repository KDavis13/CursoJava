/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancs;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author poo
 */
public class CompteEstalvisTest {
    
    public CompteEstalvisTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    
    @Test
    public void testCrearCompteEstalvisSenseSaldo() {

        CompteEstalvis ce = new CompteEstalvis("12345678");
        
        assertEquals(10d, ce.getSaldo(), 0.001d);
        
    }
    
    @Test(expected = Exception.class)
    public void testCrearCompteEstalvisSaldoInferiorMinim() throws Exception{
        
        CompteEstalvis ce = new CompteEstalvis("12345678", 5);
        
    }
    
    @Test
    public void testCrearCompteEstalvisSaldoSuperiorMinim() throws Exception{
        
        CompteEstalvis ce = new CompteEstalvis("12345678", 50d);
        
        assertEquals(50d, ce.getSaldo(), 0.001d);
        
    }
    /**
     * Test of calculaInteres method, of class CompteEstalvis.
     */
    @Test
    public void testCalculaInteres() throws Exception {
        
        CompteEstalvis ce = new CompteEstalvis("12345678", 200);
        
        assertEquals(200*0.02, ce.calculaInteres(), 0.0001d);
        
    }
    

    /**
     * Test of capitalitzaInteres method, of class CompteEstalvis.
     */
    @Test
    public void testCapitalitzaInteres() throws Exception {
        
        CompteEstalvis ce = new CompteEstalvis("12345678", 200);
        
        ce.capitalitzaInteres();
        
        assertEquals(200*1.02, ce.getSaldo(), 0.0001d);
        
    }
    
}
