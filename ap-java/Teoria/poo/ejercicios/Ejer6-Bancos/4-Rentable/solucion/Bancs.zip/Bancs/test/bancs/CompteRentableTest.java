/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancs;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author poo
 */
public class CompteRentableTest {
    
    public CompteRentableTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testCrearCompteRentable() throws Exception {

        CompteRentable cr = new CompteRentable("12345678", 18000D);
        
        cr.capitalitzaInteres();        
        double interesesAcumulados = 18000 * 0.02;
        double bonus = interesesAcumulados * 0.2;
        
        assertEquals(18000+interesesAcumulados+bonus, cr.getSaldo(), 0.001d);
        
    }
    
}
