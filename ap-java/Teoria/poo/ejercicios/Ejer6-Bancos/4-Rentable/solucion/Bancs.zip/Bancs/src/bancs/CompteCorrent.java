/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancs;


/**
 *
 * @author poo
 */
public class CompteCorrent extends CompteBancari{

    private boolean xecsEmessos;

    public CompteCorrent(String nom){
        
        super(nom);
        
    }
    
    public CompteCorrent(String nom, double saldo) throws Exception{
        
        super(nom, saldo);
        
    }
    
    final public boolean isXecsMessos() {
        
        return xecsEmessos;
        
    }

    final public void setXecsMessos(boolean xecsMessos) {
  
        this.xecsEmessos = xecsMessos;
        
    }

    @Override
    public String toString() {
        
        return super.toString() + " - té xecs? " + isXecsMessos();
        
    }
    
}
