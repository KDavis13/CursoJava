/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancs;

/**
 *
 * @author poo
 */
public interface Rentable {
    static final int MAX_LIMIT = 25_000;
    static final int MID_LIMIT = 15_000;
    static final int MIN_LIMIT = 10_000;
    
    double bonus();    
}
