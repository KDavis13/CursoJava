/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bancs;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author poo
 */
public class CompteBancariTest {
    
    public CompteBancariTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testCrearCompteSenseInformarDelSaldo() {
        
        // Fase de inicialització
        String cb = "12345678";
        
        // Possem a prova al SUT (Subject Under Test)
        CompteBancari compte1 = new CompteBancari(cb);
        
        // Avaluacio dels resultats
        assertEquals(10.0d, compte1.getSaldo(), 0.001);
    }
    
    /**
     * Test of imposicio method, of class CompteBancari.
     */
    /*@Test
    public void testImposicio() {
        System.out.println("imposicio");
        double quantitat = 0.0;
        CompteBancari instance = null;
        instance.imposicio(quantitat);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/

    /**
     * Test of reintegre method, of class CompteBancari.
     */
    /*@Test
    public void testReintegre() throws Exception {
        System.out.println("reintegre");
        double quantitat = 0.0;
        CompteBancari instance = null;
        instance.reintegre(quantitat);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }*/
    
}
